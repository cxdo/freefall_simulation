import math
import matplotlib.pyplot as plt
from scipy.integrate import odeint
import numpy as np
import scipy
from scipy import integrate

plt.rcParams['font.size'] = 18
plt.rcParams['axes.linewidth'] = 2

#read in data from chosen text file
filename = input("Enter the File you Wish to Load as Experimental Results: ")

data_1 = open(filename).read() #load file
list_1 = data_1.split(",")

disp = []
tt = []

temp = 0

for i in range(9):
  disp.append(list_1[temp])
  tt.append(list_1[temp+1])
  temp+=2

disp_p = [float(i) for i in disp]
tt_p = [float(i) for i in tt]

for i in range(9):
  disp_p[i] = disp_p[i]/100

#taking user input for the variables in the experiment
print()
print("Data Loaded")
print()
print("Object Assumed to be a Sphere")
print()

if filename == 'largeball.txt':
  m = 0.0636
  d = 0.02496
elif filename == 'mediumball.txt':
  m = 0.0434
  d = 0.02197
elif filename == 'smallball.txt':
  m = 0.0326
  d = 0.01997
else:
  m = float(input("Enter the Mass of the Object (kg): "))
  d = float(input("Enter the Diameter of the Sphere (m): "))
t_final = float(input("Enter the Time You Wish to Simulate Velocity For (s): "))

xerr = [0.0002,0.0002,0.0002,0.0002,0.0002,0.0002,0.0002,0.0002,0.0002]
yerr = [0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004, 0.004]

g = float(input("Enter the Value of g You Wish to Use: "))
r = d/2
a = r*r*math.pi

#declaring constant values to be used
h_start = 2 #drop height is 2m
p = 1.2041 #density of air at 20c
mu = 1.156*(10**-5) #viscosity of air at 20c
#drag coefficient varies over time but taking as a constant 0.5 so the equation can be solved.
cd = 0.5

k = (cd*a*p)/2
print("k value is : ", k)

terminal_velocity = math.sqrt((2*m*g)/(cd*p*a))

#terminal_reynolds = (p*terminal_velocity*a)/mu

print("Terminal Velocity = ", terminal_velocity)
print()
#print("Maximum Reynold's Number = ", terminal_reynolds)

def prop_v(v, t, k, m, g):
  return g - ((k/m)*v)

def prop_v2(v, t, k, m, g):
  return g - ((k/m)*(v**2))


t = [];
v_t = [];
x_t = [];

xs = np.linspace(0,t_final, 1000) #declaring time range
y0 = 0 #starting value of 0
ys = odeint(prop_v, y0, xs, args = (k,m,g))
y2s = odeint(prop_v2, y0, xs, args = (k,m,g))
ys = np.array(ys).flatten()
y2s = np.array(y2s).flatten()
    
fig = plt.figure(figsize=(6, 6))
ax = fig.add_axes([0.5, 0.5, 1, 1])
ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on')
ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on')
ax.set_xlabel('Time (s)', labelpad=10)
ax.set_ylabel('Velocity (m/$s^2$)', labelpad=10)
  #ax.set_xlim([0,t_final])
  #ax.set_ylim([0, terminal_velocity])
  #ax.plot(tt_p, disp_p, label = 'Experimental Results')
ax.plot(xs, y2s, label = 'Simulated Results - Drag Proportional to v Squared')
ax.plot(xs, ys, label = 'Simulated Results - Drag Proportional to v')
ax.legend(loc=2,frameon=False, fontsize=14)
ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on')
ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on')
name = input("Enter Filename to Save Velocity Graph: ")
plt.savefig(name, dpi=300, transparent=False, bbox_inches='tight')

plt.clf()

#heights = scipy.integrate.simps(y2s, xs)
heights = integrate.cumtrapz(y2s, xs, initial = 0)

for i in range(1000):
  xs[i] = xs[i]*xs[i]
  print(xs[i], heights[i])

print()
print("Integration Completed")
print()

x = np.array(tt_p)
y = np.array(disp_p)
x1 = np.array(xs)
y1 = np.array(heights)


m, b = np.polyfit(x, y, 1)

slope, intercept = np.polyfit(x1,y1,1)

print()
print("Gradient = ", slope)

fig = plt.figure(figsize=(6, 6))
ax = fig.add_axes([0.5, 0.5, 1, 1])
#ax.plot(tt_p, disp_p, label = 'Experimental Results')
ax.errorbar(tt_p, disp_p,
            xerr=xerr,
            yerr=yerr,
            marker='o',color = 'black', linestyle='none',  capsize=6, label = 'Experimental Results')
ax.plot(xs, heights, label = 'Simulated Results')
plt.plot(x, x*m+b, linestyle='--', color='black')
ax.legend(loc=2,frameon=False, fontsize=17)
ax.set_xlim([0, 0.5])
ax.set_ylim([0,h_start])
ax.set_xlabel('Time Squared ($s^2$)', labelpad=10)
ax.set_ylabel('Height Fallen (m)', labelpad=10)
ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on')
ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on')
name = input("Enter Filename to Save Height Graph: ")
plt.savefig(name, dpi=300, transparent=False, bbox_inches='tight')





    
 










